# Night Vault storefront + real authentication

This package contains the Night Vault storefront, PWA files, Privacy Policy, real email/password authentication, and authenticator-app 2FA using Supabase Auth.

## What was added

- Real **Sign Up** with email + password.
- Required **Privacy Policy / Terms** checkbox during account creation and login.
- Real **Log In** with Supabase Auth.
- **Authenticator-app 2FA (TOTP)** enrollment with a QR code and manual setup key.
- **Optional 2FA for normal users**.
- **Required authenticator 2FA for the configured Night Vault administrator**.
- Account page showing the signed-in email and 2FA status.
- Log out button.
- No passwords are stored in localStorage or by the Night Vault frontend.

Supabase's TOTP MFA flow uses a QR code/secret for enrollment and a six-digit authenticator code for verification. See the official documentation for the underlying flow.

## One-time Supabase setup

1. Create a Supabase project.
2. In Supabase, open **Authentication** and make sure Email/Password sign-in is enabled.
3. Add your deployed Night Vault URL to the Supabase project's allowed/auth redirect URLs as appropriate.
4. Open `supabase-config.js`.
5. Replace `YOUR-PROJECT` and `YOUR-PUBLISHABLE-OR-ANON-KEY` with the project's browser-safe Supabase URL and publishable/anon key.
6. In `supabase-config.js`, set `NIGHT_VAULT_ADMIN_EMAIL` to the exact administrator email address.
7. Deploy the whole folder to Netlify over HTTPS.

**Never put a Supabase `service_role` key in this website.** Only use the browser-safe publishable/anon key.

## User flow

- `signup.html` creates the account.
- If Supabase requires email confirmation, the user confirms their email and then logs in.
- After login, `account.html` lets the user enable authenticator 2FA.
- Normal users may use the site without 2FA, but can enable it from their account page.
- The configured administrator is blocked from continuing until a verified authenticator factor is enabled. After that, administrator logins require the six-digit authenticator code.
- The main store's Account button continues to use the login/sign-up UI and sends the user into the real authentication pages.

## iPhone / PWA

Deploy over HTTPS. In Safari on iPhone, open the site, tap Share, then **Add to Home Screen**.

## Important security note

This is a static storefront. The Supabase Auth session protects the account UI, but any sensitive backend data or private APIs should also enforce authentication/MFA server-side. Do not treat frontend-only hiding as authorization.


## Payhip + custom orders

- Store product cards use the Payhip checkout links already configured in `script.js`.
- A **Custom Order** form lets customers request a quantity that is not listed.
- The form uses **Netlify Forms** (`name="custom-order"`), so after deploying to Netlify you can review submissions in the Netlify dashboard under Forms.
- The custom request does **not** charge the customer. Review the request first, then send the customer the appropriate Payhip checkout link.

If you change a Payhip product URL, edit the `link` value for that product in `script.js`.


### Latest fixes
- Product cards include visible Add to Cart buttons.
- Cart checkout uses the configured Payhip product links.
- Store header switches from Log In/Sign Up to My Account/Log Out when Supabase session is active.
- iPhone Safari Add to Home Screen prompt is shown again and is not permanently suppressed by a previous dismissal.


Navigation/product update: all six Payhip products remain in Catalog. The top navigation now targets separate Home, Catalog, Deals, Bundles, Reviews, and Contact sections. Only the hQ9c2 Payhip product is featured in the Bundles section; the 6vLz2 product remains in the Catalog.
