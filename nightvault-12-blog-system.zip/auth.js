import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL = window.NIGHT_VAULT_SUPABASE_URL;
const SUPABASE_ANON_KEY = window.NIGHT_VAULT_SUPABASE_ANON_KEY;
const configured = SUPABASE_URL && SUPABASE_ANON_KEY && !SUPABASE_URL.includes('YOUR-PROJECT') && !SUPABASE_ANON_KEY.includes('YOUR-PUBLISHABLE');

export const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

export function isAdminEmail(email) {
  const admin = (window.NIGHT_VAULT_ADMIN_EMAIL || '').trim().toLowerCase();
  return !!admin && !admin.includes('YOUR-ADMIN-EMAIL') && (email || '').trim().toLowerCase() === admin;
}

export async function hasVerifiedAuthenticator() {
  if (!supabase) return false;
  const { data, error } = await supabase.auth.mfa.listFactors();
  if (error) return false;
  return !!data?.totp?.some(f => f.status === 'verified');
}

export function showMessage(el, text, type = 'info') {
  if (!el) return;
  el.textContent = text;
  el.dataset.type = type;
  el.style.display = 'block';
}

export function requireSupabase(el) {
  if (!configured) {
    showMessage(el, 'Authentication is not connected yet. Add your Supabase URL and public key to supabase-config.js, then redeploy.', 'error');
    return false;
  }
  return true;
}

export async function currentUser() {
  if (!supabase) return null;
  const { data } = await supabase.auth.getUser();
  return data.user || null;
}

export async function signOut() {
  if (supabase) await supabase.auth.signOut();
  window.location.href = 'index.html';
}

export async function enrollAuthenticator({ qrEl, secretEl, codeInput, button, messageEl }) {
  if (!requireSupabase(messageEl)) return false;
  const { data, error } = await supabase.auth.mfa.enroll({
    factorType: 'totp',
    friendlyName: 'Night Vault Authenticator'
  });
  if (error) {
    showMessage(messageEl, error.message, 'error');
    return false;
  }

  const factorId = data.id;
  if (qrEl && data.totp?.qr_code) {
    qrEl.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(data.totp.qr_code)}`;
    qrEl.hidden = false;
  }
  if (secretEl) secretEl.textContent = data.totp?.secret || '';
  if (codeInput) codeInput.focus();
  if (button) button.dataset.factorId = factorId;

  const challenge = await supabase.auth.mfa.challenge({ factorId });
  if (challenge.error) {
    showMessage(messageEl, challenge.error.message, 'error');
    return false;
  }
  if (button) button.dataset.challengeId = challenge.data.id;
  showMessage(messageEl, 'Scan the QR code with an authenticator app, then enter the 6-digit code it gives you.', 'info');
  return true;
}

export async function verifyAuthenticator({ button, codeInput, messageEl }) {
  if (!supabase) return false;
  const factorId = button?.dataset.factorId;
  const challengeId = button?.dataset.challengeId;
  const code = codeInput?.value.trim();
  if (!factorId || !challengeId) {
    showMessage(messageEl, 'Start authenticator setup first.', 'error');
    return false;
  }
  if (!/^\d{6}$/.test(code)) {
    showMessage(messageEl, 'Enter the 6-digit code from your authenticator app.', 'error');
    return false;
  }
  const { error } = await supabase.auth.mfa.verify({ factorId, challengeId, code });
  if (error) {
    showMessage(messageEl, error.message, 'error');
    return false;
  }
  showMessage(messageEl, 'Authenticator 2FA is enabled. Your account is protected by a second factor.', 'success');
  return true;
}

export async function challengeExistingAuthenticator({ codeInput, submitButton, messageEl }) {
  if (!requireSupabase(messageEl)) return false;
  const { data: factors, error } = await supabase.auth.mfa.listFactors();
  if (error) {
    showMessage(messageEl, error.message, 'error');
    return false;
  }
  const factor = factors.totp?.find(f => f.status === 'verified') || factors.totp?.[0];
  if (!factor) return false;
  const challenge = await supabase.auth.mfa.challenge({ factorId: factor.id });
  if (challenge.error) {
    showMessage(messageEl, challenge.error.message, 'error');
    return false;
  }
  submitButton.dataset.factorId = factor.id;
  submitButton.dataset.challengeId = challenge.data.id;
  codeInput.hidden = false;
  codeInput.required = true;
  codeInput.focus();
  showMessage(messageEl, 'Enter the 6-digit code from your authenticator app.', 'info');
  return true;
}

export async function verifyLoginAuthenticator({ codeInput, submitButton, messageEl }) {
  const code = codeInput.value.trim();
  if (!/^\d{6}$/.test(code)) {
    showMessage(messageEl, 'Enter the 6-digit authenticator code.', 'error');
    return false;
  }
  const { error } = await supabase.auth.mfa.verify({
    factorId: submitButton.dataset.factorId,
    challengeId: submitButton.dataset.challengeId,
    code
  });
  if (error) {
    showMessage(messageEl, error.message, 'error');
    return false;
  }
  return true;
}
