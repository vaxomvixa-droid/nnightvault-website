const products = [
 {name:"200+ Vendors", cat:"vendors", price:30.00, old:37.50, off:"20% OFF", desc:"A categorized directory of 200+ vendor and supplier sources for resellers.", best:true, link:"https://payhip.com/b/f0T6u"},
 {name:"400+ Vendors", cat:"vendors", price:40.00, old:80.00, off:"50% OFF • LIMITED TIME", desc:"A categorized directory of 400+ vendor and supplier sources for resellers.", best:true, link:"https://payhip.com/b/e724L"},
 {name:"Pro Reseller Bundle", cat:"bundles", price:60.00, old:100.00, off:"40% OFF", desc:"A bundle that takes every product into one.", best:true, link:"https://payhip.com/b/hQ9c2"},
 {name:"Starter Resell Guide", cat:"guides", price:14.99, old:18.74, off:"20% OFF", desc:"A beginner-friendly reselling guide to help you learn the basics and start your reselling journey.", best:true, link:"https://payhip.com/b/yg9xs"},
 {name:"Pro Reseller Guide", cat:"guides", price:30.00, old:60.00, off:"HOT DEAL • 50% OFF", desc:"An advanced reselling guide with strategies and resources for taking your reselling to the next level.", best:true, link:"https://payhip.com/b/leaGz"}
];
products.forEach((p,i)=>{ p.addedOrder=i; });
window.nightVaultProducts = products;

let cart = JSON.parse(localStorage.getItem("nightvault-cart") || "[]");
function productKey(link){ return (String(link).match(/\/b\/([^/?#]+)/)||[])[1] || ""; }
window.productKey = productKey;
function saveCart(){ localStorage.setItem("nightvault-cart",JSON.stringify(cart)); }
function updateCartCount(){ const el=document.getElementById("cartCount"); if(el) el.textContent=cart.reduce((s,i)=>s+i.qty,0); }
function toast(text){ const t=document.getElementById("toast"); if(!t)return; t.textContent=text;t.style.display="block";clearTimeout(window.__nvToast);window.__nvToast=setTimeout(()=>t.style.display="none",1800); }
function addToCart(name, link, qty=1){
 qty=Math.max(1,Math.min(100,Number(qty)||1)); const existing=cart.find(i=>i.link===link);
 if(existing) existing.qty+=qty; else cart.push({name,link,qty});
 saveCart();updateCartCount();renderCart();toast(`${name} added to cart`);
}
window.addToCart=addToCart;
function changeQty(link,delta){ const item=cart.find(i=>i.link===link);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(i=>i.link!==link);saveCart();updateCartCount();renderCart(); }
function clearCart(){cart=[];saveCart();updateCartCount();renderCart();}
function checkoutCart(){
 if(!cart.length){toast("Your cart is empty");return;}
 const links=[];cart.forEach(i=>{for(let n=0;n<i.qty;n++)links.push(productKey(i.link));});
 const url="https://payhip.com/buy?"+links.map(k=>"cart_links[]="+encodeURIComponent(k)).join("&");
 window.location.href=url;
}
function renderCart(){
 const panel=document.getElementById("cartPanel");if(!panel)return;
 panel.innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><div><strong>${i.name}</strong><small>Quantity: ${i.qty}</small></div><div class="cart-controls"><button type="button" data-cart-action="minus" data-link="${i.link}">−</button><b>${i.qty}</b><button type="button" data-cart-action="plus" data-link="${i.link}">+</button></div></div>`).join(""): '<div class="cart-empty">Your cart is empty.</div>';
}
const productImages={
 "200+ Vendors":"assets/products/200-vendors.png",
 "400+ Vendors":"assets/products/400-vendors.png",
 "Starter Resell Guide":"assets/products/starter-resell-guide.png",
 "Pro Reseller Guide":"assets/products/pro-reseller-guide.png",
 "Pro Reseller Bundle":"assets/products/pro-reseller-bundle.png"
};
// Display currency switcher (USD is the base price; checkout remains in the seller's configured currency).
let nvCurrency=localStorage.getItem("nightvault-currency")||"USD";
let nvRates={USD:1};
let nvRatesPromise=null;
function nvFormatPrice(amount){
 const rate=Number(nvRates[nvCurrency]||1);
 try{return new Intl.NumberFormat(undefined,{style:"currency",currency:nvCurrency,maximumFractionDigits:nvCurrency==="JPY"||nvCurrency==="KRW"?0:2}).format(Number(amount)*rate);}
 catch(e){return "$"+(Number(amount)*rate).toFixed(2);}
}
async function nvLoadRates(){
 if(nvRatesPromise)return nvRatesPromise;
 nvRatesPromise=fetch("https://open.er-api.com/v6/latest/USD").then(r=>r.json()).then(data=>{
   if(data&&data.rates){nvRates={USD:1,...data.rates};localStorage.setItem("nightvault-currency-rates",JSON.stringify({rates:nvRates,time:Date.now()}));}
   return nvRates;
 }).catch(()=>{try{const c=JSON.parse(localStorage.getItem("nightvault-currency-rates")||"null");if(c&&c.rates)nvRates=c.rates;}catch(e){}return nvRates;});
 return nvRatesPromise;
}
function nvApplyCurrency(){
 const btn=document.getElementById("currencyButton"),sel=document.getElementById("currencySelect");
 if(btn)btn.textContent=nvCurrency+" ▾"; if(sel)sel.value=nvCurrency;
 filterProducts();
}
function nvInitCurrency(){
 const btn=document.getElementById("currencyButton"),sel=document.getElementById("currencySelect");
 if(!btn||!sel)return;
 btn.addEventListener("click",()=>{const open=sel.classList.toggle("is-open");btn.setAttribute("aria-expanded",String(open));if(open)sel.focus();});
 sel.addEventListener("change",async()=>{nvCurrency=sel.value;localStorage.setItem("nightvault-currency",nvCurrency);sel.classList.remove("is-open");btn.setAttribute("aria-expanded","false");await nvLoadRates();nvApplyCurrency();});
 document.addEventListener("click",e=>{if(!e.target.closest(".currency-wrap")){sel.classList.remove("is-open");btn.setAttribute("aria-expanded","false");}});
 nvLoadRates().then(nvApplyCurrency);
}
function card(p){
 const detailsUrl=`product.html?id=${encodeURIComponent(productKey(p.link))}`;
 const image=productImages[p.name]||"";
 return `<article class="card nv-flip-card" data-product-link="${detailsUrl}" tabindex="0" aria-label="${p.name}. Tap product image to flip for details">
   <div class="nv-flip-inner">
     <div class="nv-flip-face nv-flip-front">
       <div class="card-img nv-product-art">${image?`<img src="${image}" alt="${p.name} product cover" loading="lazy">`:''}<span class="badge">🔥 ${p.off}</span><span class="nv-flip-hint">TAP TO FLIP ↻</span></div>
       <div class="card-body"><a class="product-title-link" href="${detailsUrl}"><h3>${p.name}</h3></a><p>${p.desc}</p><span class="price">${nvFormatPrice(p.price)}</span> <span class="old">${nvFormatPrice(p.old)}</span>
       <div class="card-actions"><button class="add-cart-button" type="button" data-product="${encodeURIComponent(p.name)}" data-link="${p.link}">ADD TO CART</button><a class="buy-button" href="${p.link}" target="_blank" rel="noopener">BUY NOW →</a></div></div>
     </div>
     <div class="nv-flip-face nv-flip-back">
       <div><span class="nv-back-kicker">NIGHT VAULT</span><h3>${p.name}</h3><p>${p.desc}</p><div class="nv-back-price">${nvFormatPrice(p.price)} <small>${nvFormatPrice(p.old)}</small></div><p class="nv-back-tip">Tap again to return to the product cover.</p></div>
     </div>
   </div>
 </article>`;
}
function render(list,id){const el=document.getElementById(id);if(el)el.innerHTML=list.map(card).join("");}
function filterProducts(){
 const a=document.getElementById("catalogSearch"),b=document.getElementById("topSearch"); if(!a||!b)return;
 const q=(a.value+" "+b.value).toLowerCase(),active=document.querySelector(".filter.active")?.dataset.cat||"all";
 let filtered=products.filter(p=>(active==="all"||p.cat===active)&&(!q||`${p.name} ${p.desc} ${p.cat}`.toLowerCase().includes(q)));
 const sort=document.getElementById("sortProducts")?.value||"featured";
 filtered=[...filtered].sort((x,y)=>{
   if(sort==="price-asc") return x.price-y.price;
   if(sort==="price-desc") return y.price-x.price;
   if(sort==="best") return (y.best===true)-(x.best===true) || x.price-y.price;
   if(sort==="newest") return y.addedOrder-x.addedOrder;
   return x.addedOrder-y.addedOrder;
 });
 render(filtered,"productGrid");
 const deals=products.filter(p=>p.off && p.off.toLowerCase().includes("off"));
 render(deals,"dealsGrid");
 const bundle=products.filter(p=>p.link==="https://payhip.com/b/hQ9c2");
 render(bundle,"bundleGrid");
}

document.addEventListener("click",e=>{
 const flip=e.target.closest?.(".nv-flip-card");
 if(flip && !e.target.closest("a,button")){ flip.classList.toggle("is-flipped"); }
 const add=e.target.closest?.(".add-cart-button");if(add){addToCart(decodeURIComponent(add.dataset.product),add.dataset.link);return;}
 const action=e.target.closest?.("[data-cart-action]");if(action){changeQty(action.dataset.link,action.dataset.cartAction==="plus"?1:-1);return;}
});

document.addEventListener("DOMContentLoaded",()=>{
 nvInitCurrency();
 document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");filterProducts();}));
 document.getElementById("catalogSearch")?.addEventListener("input",filterProducts);
 document.getElementById("sortProducts")?.addEventListener("change",filterProducts);
 const top=document.getElementById("topSearch"), clear=document.getElementById("searchClear"), results=document.getElementById("searchResults"), searchWrap=top?.closest(".search");
 function updateSearchUI(){ if(!top)return; const q=top.value.trim().toLowerCase(); searchWrap?.classList.toggle("has-value",!!q); if(!results)return; if(!q){results.classList.remove("show");results.innerHTML="";return;} const matches=products.filter(p=>`${p.name} ${p.desc} ${p.cat}`.toLowerCase().includes(q)).slice(0,5); results.innerHTML=matches.length?matches.map(p=>`<a class="search-result" href="product.html?id=${encodeURIComponent(productKey(p.link))}" role="option"><strong>${p.name}</strong><small>${p.cat} · $${p.price.toFixed(2)}</small></a>`).join(""):'<div class="search-empty">No products found. Try another search.</div>'; results.classList.add("show"); }
 top?.addEventListener("input",()=>{filterProducts();updateSearchUI();});
 top?.addEventListener("keydown",e=>{if(e.key==="Escape"){top.value="";filterProducts();updateSearchUI();top.blur();}});
 clear?.addEventListener("click",()=>{if(top){top.value="";filterProducts();updateSearchUI();top.focus();}});
 document.addEventListener("click",e=>{if(searchWrap&&!searchWrap.contains(e.target))results?.classList.remove("show")});
 document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();top?.focus();}});
 updateSearchUI();
 document.getElementById("cartButton")?.addEventListener("click",()=>{renderCart();document.getElementById("cartOverlay")?.classList.add("open");});
 document.getElementById("cartClose")?.addEventListener("click",()=>document.getElementById("cartOverlay")?.classList.remove("open"));
 document.getElementById("cartCheckout")?.addEventListener("click",checkoutCart);document.getElementById("cartClear")?.addEventListener("click",clearCart);
 document.getElementById("cartOverlay")?.addEventListener("click",e=>{if(e.target.id==="cartOverlay")e.target.classList.remove("open")});
 const cp=document.getElementById("customProduct");if(cp)products.forEach(p=>{const o=document.createElement("option");o.value=p.name;o.textContent=p.name;cp.appendChild(o);});
 updateCartCount();renderCart();filterProducts();
});

// Free reseller profit calculator
function updateProfitCalculator(){
 const n=id=>Math.max(0,Number(document.getElementById(id)?.value)||0);
 const cost=n("profitCost"), sale=n("profitSale"), qty=Math.max(1,Math.floor(n("profitQty"))), fee=Math.min(100,n("profitFee"))/100, shipping=n("profitShipping"), other=n("profitOther");
 const revenue=sale*qty, fees=revenue*fee, costs=(cost+shipping+other)*qty+fees, profit=revenue-costs, perItem=profit/qty, margin=revenue?profit/revenue*100:0, roi=((cost+shipping+other)*qty)?profit/((cost+shipping+other)*qty)*100:0;
 const money=v=>`$${v.toFixed(2)}`;
 const set=(id,val)=>{const el=document.getElementById(id);if(el){el.textContent=val;el.classList.toggle("negative",String(val).startsWith("-$"))}};
 set("profitRevenue",money(revenue)); set("profitCosts",money(costs)); set("profitTotal",money(profit)); set("profitPerItem",money(perItem)); set("profitMargin",`${margin.toFixed(2)}%`); set("profitROI",`${roi.toFixed(2)}%`);
}
window.updateProfitCalculator=updateProfitCalculator;
document.addEventListener("DOMContentLoaded",()=>{["profitCost","profitSale","profitQty","profitFee","profitShipping","profitOther"].forEach(id=>document.getElementById(id)?.addEventListener("input",updateProfitCalculator));updateProfitCalculator();});


document.addEventListener("DOMContentLoaded",()=>{
 const more=document.querySelector('.more-nav'), btn=document.querySelector('.more-nav-button');
 if(btn&&more){btn.addEventListener('click',()=>{const open=more.classList.toggle('open');btn.setAttribute('aria-expanded',open);});document.addEventListener('click',e=>{if(!more.contains(e.target)){more.classList.remove('open');btn.setAttribute('aria-expanded','false');}});}
});

// Night Vault animated page transitions
(function(){
  if(document.getElementById('nv-page-transition')) return;
  const overlay=document.createElement('div');
  overlay.id='nv-page-transition';
  document.body.appendChild(overlay);
  document.querySelectorAll('a[href]').forEach(a=>a.addEventListener('click',function(e){
    const href=a.getAttribute('href');
    if(!href || href.startsWith('#') || a.target==='_blank' || a.hasAttribute('download') || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    let url; try{url=new URL(href,location.href)}catch{return}
    if(url.origin!==location.origin || url.href===location.href) return;
    e.preventDefault();
    overlay.classList.add('nv-transitioning');
    setTimeout(()=>location.href=url.href,460);
  }));
  window.addEventListener('pageshow',()=>{overlay.classList.remove('nv-transitioning')});
})();

// Load Supabase products and MERGE them with the existing NIGHTVAULT catalog.
// Uses only the public publishable key and the table's public SELECT policy.
async function loadSupabaseProducts(){
  const url=window.NIGHT_VAULT_SUPABASE_URL;
  const key=window.NIGHT_VAULT_SUPABASE_ANON_KEY;
  if(!url||!key) return;
  try{
    const res=await fetch(url.replace(/\/$/, '')+'/rest/v1/products?select=*',{headers:{apikey:key,Authorization:'Bearer '+key}});
    if(!res.ok) throw new Error('Supabase '+res.status);
    const rows=await res.json();
    const existing=new Set(products.map(p=>String(p.link||'').toLowerCase()));
    rows.forEach((r,i)=>{
      const link=r.link||r.Link||'#';
      const name=r.name||'NIGHTVAULT Product';
      if(existing.has(String(link).toLowerCase())) return;
      const price=Number(r.price)||0;
      products.push({name,cat:'guides',price,old:price,off:'NEW',desc:r.description||'',best:false,link,addedOrder:10000+i});
    });
    filterProducts();
  }catch(err){
    console.warn('Supabase products could not load:',err);
    // Existing catalog remains visible even if Supabase is unavailable.
  }
}
document.addEventListener('DOMContentLoaded',()=>{setTimeout(loadSupabaseProducts,0);});

// Keyboard accessibility for product flips
document.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.classList?.contains("nv-flip-card")){e.preventDefault();e.target.classList.toggle("is-flipped");}});
