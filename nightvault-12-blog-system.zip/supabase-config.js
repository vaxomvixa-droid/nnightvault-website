// Night Vault authentication configuration.
// Replace these two placeholders with your Supabase project's public browser values.
// The publishable/anon key is intended for browser use; NEVER put a service_role key here.
window.NIGHT_VAULT_SUPABASE_URL = 'https://iccdivoigvgsmkdyigcn.supabase.co';
window.NIGHT_VAULT_SUPABASE_ANON_KEY = 'sb_publishable_6DPqRn-Cw1LaXRvcQq5JMQ_3Pwj7l0R';

// Set this to the exact email address of the Night Vault administrator.
// The admin must have verified TOTP 2FA before accessing the account/store.
window.NIGHT_VAULT_ADMIN_EMAIL = 'flixdestroy@gmail.com';
