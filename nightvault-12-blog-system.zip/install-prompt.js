(function () {
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isMacTouch = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
  if (isIOS || isMacTouch) document.documentElement.classList.add('nv-ios');
  if (isStandalone || !(isIOS || isMacTouch)) return;

  function showPrompt() {
    if (document.getElementById('nv-install-prompt')) return;
    const wrap = document.createElement('div');
    wrap.id = 'nv-install-prompt';
    wrap.innerHTML = `
      <div class="nv-install-backdrop"></div>
      <div class="nv-install-card" role="dialog" aria-modal="true" aria-labelledby="nv-install-title">
        <button class="nv-install-close" aria-label="Close">×</button>
        <div class="nv-install-icon">♛</div>
        <h2 id="nv-install-title">Add Night Vault to your Home Screen</h2>
        <p>Install Night Vault for quick access and an app-like experience on your iPhone.</p>
        <div class="nv-install-steps">
          <div><b>1</b><span>Tap the <strong>Share</strong> button in Safari.</span></div>
          <div><b>2</b><span>Scroll down and tap <strong>Add to Home Screen</strong>.</span></div>
          <div><b>3</b><span>Tap <strong>Add</strong>.</span></div>
        </div>
        <button class="nv-install-ok">Show me how</button>
        <button class="nv-install-later">Not now</button>
      </div>`;
    document.body.appendChild(wrap);
    const close = () => wrap.remove();
    wrap.querySelector('.nv-install-close').addEventListener('click', close);
    wrap.querySelector('.nv-install-ok').addEventListener('click', close);
    wrap.querySelector('.nv-install-later').addEventListener('click', close);
  }
  window.addEventListener('load', () => setTimeout(showPrompt, 700));
})();
