exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, x-nightvault-secret",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method not allowed. Use POST." })
    };
  }

  const expectedSecret = process.env.NIGHTVAULT_ADMIN_SECRET;
  if (expectedSecret) {
    const providedSecret = event.headers["x-nightvault-secret"] || event.headers["X-Nightvault-Secret"];
    if (providedSecret !== expectedSecret) {
      return {
        statusCode: 401,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Unauthorized" })
      };
    }
  }

  let product;
  try {
    product = JSON.parse(event.body || "{}");
  } catch {
    return {
      statusCode: 400,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Request body must be valid JSON." })
    };
  }

  const name = typeof product.name === "string" ? product.name.trim() : "";
  const price = product.price;
  const link = typeof product.link === "string" ? product.link.trim() : "";
  const description = typeof product.description === "string" ? product.description.trim() : "";

  if (!name || price === undefined || price === null || !link) {
    return {
      statusCode: 400,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({
        error: "Missing required fields.",
        required: ["name", "price", "link"]
      })
    };
  }

  const numericPrice = Number(String(price).replace(/[$,]/g, ""));
  if (!Number.isFinite(numericPrice) || numericPrice < 0) {
    return {
      statusCode: 400,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "price must be a valid non-negative number." })
    };
  }

  try {
    new URL(link);
  } catch {
    return {
      statusCode: 400,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "link must be a valid URL." })
    };
  }

  // This endpoint confirms that the product request was received.
  // Persistent storage or Discord announcements can be added later.
  const createdProduct = {
    id: `nv_${Date.now()}`,
    name,
    price: numericPrice,
    link,
    description,
    createdAt: new Date().toISOString()
  };

  return {
    statusCode: 201,
    headers: { ...cors, "Content-Type": "application/json" },
    body: JSON.stringify({ success: true, product: createdProduct })
  };
};
