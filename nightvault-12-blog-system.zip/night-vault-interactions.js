(function(){
  const glow=document.createElement('div');glow.className='nv-cursor-glow';document.body.appendChild(glow);
  let tx=-500,ty=-500,cx=-500,cy=-500;
  addEventListener('pointermove',e=>{tx=e.clientX;ty=e.clientY});
  (function loop(){cx+=(tx-cx)*.16;cy+=(ty-cy)*.16;glow.style.left=cx+'px';glow.style.top=cy+'px';requestAnimationFrame(loop)})();
  const targets=[...document.querySelectorAll('.product-card,.card,.product,.item,.nv-feature,.nv-page-section')];
  targets.forEach(el=>el.classList.add('nv-reveal'));
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}}),{threshold:.12});targets.forEach(el=>io.observe(el));
  const grid=document.querySelector('#productGrid,.products-grid,.product-grid');
  if(grid&&grid.children.length>1&&!document.querySelector('.nv-featured-carousel')){
    const wrap=document.createElement('div');wrap.className='nv-featured-carousel';
    const controls=document.createElement('div');controls.className='nv-carousel-controls';
    const prev=document.createElement('button'),next=document.createElement('button');prev.className=next.className='nv-carousel-btn';prev.textContent='←';next.textContent='→';controls.append(prev,next);
    const track=document.createElement('div');track.className='nv-featured-track';
    [...grid.children].slice(0,8).forEach(c=>track.appendChild(c.cloneNode(true)));
    wrap.append(controls,track);grid.parentNode.insertBefore(wrap,grid);
    prev.onclick=()=>track.scrollBy({left:-360,behavior:'smooth'});next.onclick=()=>track.scrollBy({left:360,behavior:'smooth'});
  }
})();
