import { supabase } from './auth.js';
const login=document.getElementById('topLogin'), signup=document.getElementById('topSignup'), account=document.getElementById('topAccount'), logout=document.getElementById('topLogout');
function setStatus(user){const yes=!!user;if(login)login.hidden=yes;if(signup)signup.hidden=yes;if(account)account.hidden=!yes;if(logout)logout.hidden=!yes;}
if(supabase){
  supabase.auth.getSession().then(({data})=>setStatus(data?.session?.user||null));
  supabase.auth.onAuthStateChange((_e,session)=>setStatus(session?.user||null));
  logout?.addEventListener('click',async()=>{await supabase.auth.signOut();setStatus(null);});
}else setStatus(null);
