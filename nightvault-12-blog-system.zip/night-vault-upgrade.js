
/* Night Vault UX enhancements */
(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];

  // Toast helper
  let toast = document.querySelector('.nv-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'nv-toast';
    document.body.appendChild(toast);
  }
  window.nvToast = (msg) => {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(window.__nvToastTimer);
    window.__nvToastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  };

  // Product search: filters common product-card elements without assuming a specific framework.
  const input = $('#nv-product-search');
  if (input) {
    input.addEventListener('input', () => {
      const q = input.value.trim().toLowerCase();
      const candidates = $$('[data-product], .product-card, .product, .card');
      candidates.forEach(card => {
        const text = (card.textContent || '').toLowerCase();
        card.style.display = (!q || text.includes(q)) ? '' : 'none';
      });
    });
  }

  // Add a small accessibility/utility enhancement to external checkout links.
  $$('a[target="_blank"]').forEach(a => {
    const rel = (a.getAttribute('rel') || '').split(/\s+/).filter(Boolean);
    if (!rel.includes('noopener')) rel.push('noopener');
    a.setAttribute('rel', rel.join(' '));
  });
})();

// Mobile menu and custom-order UX
(() => {
  const toggle = document.getElementById('mobileNavToggle');
  const nav = document.getElementById('mainNav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.firstChild.textContent = open ? '✕ ' : '☰ ';
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.firstChild.textContent = '☰ ';
    }));
  }

  const form = document.querySelector('form[name="custom-order"]');
  if (form) {
    form.addEventListener('submit', () => {
      const btn = form.querySelector('button[type="submit"]');
      const success = document.getElementById('customOrderSuccess');
      const error = document.getElementById('customOrderError');
      form.classList.add('is-submitting');
      if (btn) { btn.disabled = true; btn.textContent = 'SENDING…'; }
      if (success) success.hidden = true;
      if (error) error.hidden = true;
    });
  }
})();
